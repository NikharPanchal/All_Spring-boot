package com.aspire.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUserRestApiApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(SpringUserRestApiApplication.class, args);
	}

}
